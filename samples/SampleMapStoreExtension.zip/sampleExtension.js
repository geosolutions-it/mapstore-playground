(window.webpackJsonp = window.webpackJsonp || []).push([
    ["extensions/sampleExtension"], {
        "./build/extensions/plugins/SampleExtension.jsx": function (e, n, t) {
            "use strict";
            t.r(n);
            var o = t("./node_modules/react-redux/es/index.js"),
                l = t("./node_modules/react/index.js"),
                a = t.n(l),
                i = t("./web/client/components/I18N/Message.jsx"),
                s = t.n(i),
                u = {
                    backgroundColor: "rgba(255,255,255,.9)",
                    borderRadius: 10,
                    maxWidth: 550,
                    padding: 10,
                    margin: 10,
                    position: "absolute",
                    top: 50,
                    zIndex: 1e3
                },
                r = function (e) {
                    var n = e.value,
                        t = void 0 === n ? 0 : n,
                        o = e.onIncrease,
                        l = e.changeZoomLevel;
                    return a.a.createElement("div", {
                        id: "SAMPLE_EXTENSION",
                        style: u
                    }, a.a.createElement("h2", null, "Extension Sample"), a.a.createElement("div", null, "This is a sample extension plugin. The following tools demonstrate the correct binding inside MapStore"), a.a.createElement("h3", null, "State and epics"), a.a.createElement("div", null, "A button like this should be visualized also in the toolbar: ", a.a.createElement("br", null), a.a.createElement("button", {
                        onClick: o,
                        className: "btn-primary square-button btn"
                    }, "INC"), a.a.createElement("br", null), " "), a.a.createElement("div", null, "Clicking on that button (or on the button above) should increase this counter value: ", a.a.createElement("b", null, t), ". ", a.a.createElement("br", null), "The counter value updates should be logged in console by an epic"), a.a.createElement("i", null, 'note: the button in the toolbar can be hidden, in this case click on the "..." button'), a.a.createElement("h3", null, "Localization"), "The following text should be localized: ", a.a.createElement("b", null, a.a.createElement(s.a, {
                        msgId: "extension.message"
                    })), a.a.createElement("br", null), ' (you should see something like "Message!" if your language is set to en-US)', a.a.createElement("h3", null, "Core action"), 'This button should change the zoom level to "1"', a.a.createElement("button", {
                        onClick: function () {
                            l(1)
                        }
                    }, "zoom to level 1"))
                },
                c = t("./node_modules/rxjs/Rx.js"),
                m = t.n(c),
                d = t("./web/client/actions/map.js");
            n.default = {
                name: "SampleExtension",
                component: Object(o.connect)((function (e) {
                    return {
                        value: e.sampleExtension && e.sampleExtension.value
                    }
                }), {
                    onIncrease: function () {
                        return {
                            type: "INCREASE_COUNTER"
                        }
                    },
                    changeZoomLevel: d.changeZoomLevel
                })(r),
                reducers: {
                    sampleExtension: function () {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                            value: 1
                        },
                            n = arguments.length > 1 ? arguments[1] : void 0;
                        return "INCREASE_COUNTER" === n.type ? {
                            value: e.value + 1
                        } : e
                    }
                },
                epics: {
                    logCounterValue: function (e, n) {
                        return e.ofType("INCREASE_COUNTER").switchMap((function () {
                            return console.log("CURRENT VALUE: " + n.getState().sampleExtension.value), m.a.Observable.empty()
                        }))
                    }
                },
                containers: {
                    Toolbar: {
                        name: "sampleExtension",
                        position: 10,
                        text: "INC",
                        doNotHide: !0,
                        action: function () {
                            return {
                                type: "INCREASE_COUNTER"
                            }
                        },
                        priority: 1
                    }
                }
            }
        }
    }
]);
